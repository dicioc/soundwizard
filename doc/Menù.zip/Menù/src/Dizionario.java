public class Dizionario {
   protected static String words[] = new String[50];

   public void lingua_Italiano(){
       words[0] = "1. Crea file";
       words[1] = "2. Apri file";
       words[2] = "3. Converti da .mp3 a .wav";
       words[3] = "4. Salva";
       words[4] = "5. Salva con nome";
       words[5] = "6. Impostazioni";
   }
   public void lingua_Inglese(){
       words[0]="1. Create a file";
       words[1]="2. Open a file";
       words[2]="3. Save";
       words[3]="4. Save with name";
       words[4]="5. Convert from .mp3 to .wav";
       words[5]="6. Settings";
   }
   public void lingua_Giapponese(){
       words[0]="1. ファイルを作成します";
       words[1]="2. 開いているファイル";
       words[2]="3. セーブ";
       words[3]="4. 新規保管";
       words[4]="5. 輸出.WAV";
       words[5]="6. 設定";
   }
   public void copia(String[] Array, String lingua){
       if(lingua.equalsIgnoreCase("italiano")){
           for(int i = 0; i < Array.length; i++) {
               lingua_Italiano();
               Array[i] = words[i];
           }
       }
   }
}
   
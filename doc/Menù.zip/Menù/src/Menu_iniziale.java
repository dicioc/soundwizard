
import java.util.*;

public class Menu_iniziale {
	static Scanner in = new Scanner(System.in);
	
	private static String lingua;
	protected static String words[] = new String[50];
	
	public static void menu(String lingua) {
		Dizionario d=new Dizionario();
		
		
	}
	
	public static void main(String[] args) {
		
		System.out.println("select language:    Italiano    English    日本の\nWrite your language here.");
		lingua=in.nextLine();
		menu(lingua);
		
	}

}
